#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter the values of A and B:");
    scanf("%d %d",&a,&b);
    printf("BEFORE SWAPPING:%d %d",a,b);
    a=a+b;
    b=a-b;
    a=a-b;
   
    printf("AFTER SWAPPING:%d %d",a,b);
}